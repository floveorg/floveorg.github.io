#!/usr/bin/env bash
# START-ANDROID.sh — run inside Termux on the phone.
# Serves the flove-solo folder beside this script and opens start.html on your
# phone's own http://localhost:8642 (localhost on the phone = secure context, so
# the offline service worker works). No shared Wi-Fi or network needed.
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$HERE/flove-solo"
PORT=8642
ENTRY="start.html"
URL="http://localhost:${PORT}/${ENTRY}"

command -v python3 >/dev/null 2>&1 || python3 --version 2>/dev/null || {
  echo "Termux needs python: run  pkg install python  in Termux first."
  exit 1
}

# Stop anything already serving 8642 so this copy wins.
if command -v lsof >/dev/null 2>&1; then
  PIDS="$(lsof -ti tcp:8642 2>/dev/null | tr '\n' ' ')"
elif command -v pgrep >/dev/null 2>&1; then
  PIDS="$(pgrep -f 'http.server 8642' 2>/dev/null | tr '\n' ' ')"
else
  PIDS=""
fi
[ -n "$PIDS" ] && kill $PIDS 2>/dev/null || true

cd "$ROOT" || { echo "No encuentro la carpeta flove-solo"; exit 1; }
nohup python3 -m http.server "$PORT" >/tmp/flove-server.log 2>&1 &
sleep 1

# Open in the phone's browser (start is Termux's tool). Fall back gracefully.
if command -v termux-open-url >/dev/null 2>&1; then
  termux-open-url "$URL"
else
  echo "flove listo → abrelo en tu navegador: $URL"
fi
echo "flove serving locally on this phone at $URL"
