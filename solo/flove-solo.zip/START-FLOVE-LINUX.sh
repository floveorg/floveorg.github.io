#!/usr/bin/env bash
# START-FLOVE-LINUX.sh — run this. Serves the folder beside this script and
# opens flove-solo/start.html at http://localhost:8642. It stops anything
# already serving 8642 (an older download) so this copy is the one that shows,
# and on first run drops a flove icon into your applications menu (and Desktop).
set -uo pipefail

SELF="$(readlink -f "$0")"
HERE="$(cd "$(dirname "$SELF")" && pwd)"
ROOT="$HERE/flove-solo"               # the package: flattened app + docs/
PORT=8642
ENTRY="start.html"
URL="http://localhost:${PORT}/${ENTRY}"

# ── Phones: where to open flove ├────────────────────────────────────────────
# A phone can never reach this computer's "localhost". It must load the same
# package over the LAN (same Wi-Fi) — or over Tailscale if you have it (any
# network, and HTTPS, so offline/PWA works on the phone). We expose these in
# devices.json (read by the app's Settings ▸ Devices section to show/QR them).
lan_ips() { hostname -I 2>/dev/null | tr ' ' '\n' \
            | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' \
            | grep -v '^127\.' || true; }
tailscale_url() { command -v tailscale >/dev/null 2>&1 \
  && tailscale ip -4 2>/dev/null | head -1 | sed "s#^#http://#; s#\$#:$PORT#"; }
write_devices() {
  local out lan="[" ip ts fst=1
  for ip in $(lan_ips); do
    [ -n "$ip" ] || continue
    if [ "$fst" -eq 1 ]; then lan="$lan\"http://$ip:$PORT\""; fst=0; else lan="$lan, \"http://$ip:$PORT\""; fi
  done
  out="{\"port\":$PORT,\"localhost\":\"$URL\",\"lan\":$lan]"
  ts="$(tailscale_url)"; [ -n "$ts" ] && out="$out,\"tailscale\":\"$ts\""
  out="$out}"
  printf '%s\n' "$out" > "$ROOT/devices.json" 2>/dev/null || true
  echo "──────────────────────────────────────────────────────────"
  echo "  Open flove on a phone (ranked):"
  echo "    1 · Termux (this phone):      install Termux, copy this package to the"
  echo "                                  phone and run START-ANDROID.sh (no network)."
  [ -n "$ts" ] && echo "    2 · Tailscale (any network):  $ts/"
  for ip in $(lan_ips); do [ -n "$ip" ] && echo "    3 · same Wi-Fi:                       http://$ip:$PORT/"; done
  echo "    · this computer:               $URL"
  echo "  Phone wants a QR: open here ▸ Settings ▸ Devices (or scan on the same page)."
  echo "──────────────────────────────────────────────────────────"
}
write_devices

port_open() { (exec 3<>"/dev/tcp/127.0.0.1/${PORT}") 2>/dev/null; }
opener() { xdg-open "$1" >/dev/null 2>&1 || open "$1" >/dev/null 2>&1 & }

# Take over the port: an older flove localhost (previous download) may already
# be serving 8642 — stop it so THIS folder is the one that shows. Update
# behavior. Older downloads predate this and can't take over the port, so they
# are superseded by the newest download — not backwards compatible.
stop_existing() {
  local pids=""
  if command -v lsof >/dev/null 2>&1; then
    pids="$(lsof -ti tcp:8642 2>/dev/null | tr '\n' ' ')"
  else
    pids="$(pgrep -f 'http.server 8642' 2>/dev/null | tr '\n' ' ')"
  fi
  [ -n "$pids" ] || return 0
  kill $pids 2>/dev/null || true
  sleep 0.3
  if command -v notify-send >/dev/null 2>&1; then
    notify-send "flove" "Actualizado: se detuvo un flove localhost anterior; esta copia es la activa."
  else
    echo "flove: actualizado — se reemplazó un flove localhost anterior." >&2
  fi
}

# Create a real menu/desktop icon that points back to this very script.
make_icon() {
  local apps="$HOME/.local/share/applications"
  mkdir -p "$apps" 2>/dev/null || return 0
  cat > "$apps/flove-localhost.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=flove (localhost)
Comment=Serve flove on localhost and open it
Exec="$SELF"
Icon=$ROOT/apple-touch-icon.png
Terminal=false
StartupNotify=true
Categories=Network;
EOF
  chmod +x "$apps/flove-localhost.desktop" 2>/dev/null || true
  update-desktop-database "$apps" >/dev/null 2>&1 || true
  if [ -d "$HOME/Desktop" ]; then
    cp "$apps/flove-localhost.desktop" "$HOME/Desktop/" 2>/dev/null || true
    chmod +x "$HOME/Desktop/flove-localhost.desktop" 2>/dev/null || true
    gio set "$HOME/Desktop/flove-localhost.desktop" metadata::trusted true 2>/dev/null || true
  fi
}
make_icon
stop_existing

if ! port_open; then
  cd "$ROOT" || { command -v notify-send >/dev/null && notify-send "flove" "No encuentro la carpeta flove-solo"; exit 1; }
  nohup python3 -m http.server "$PORT" >/tmp/flove-server.log 2>&1 &
  disown
  for _ in $(seq 1 20); do port_open && break; sleep 0.2; done
fi

if port_open; then
  opener "$URL"                          # localhost: reliable storage + secure context
else
  command -v notify-send >/dev/null && notify-send "flove" \
    "Sin servidor local — abriendo el fichero directo (file://), modo degradado."
  opener "$ROOT/${ENTRY}"
fi
