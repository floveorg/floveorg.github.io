#!/usr/bin/env bash
# START-FLOVE-MAC.command — macOS: serves the folder beside this file and opens
# flove-solo/start.html at http://localhost:8642. Stops anything already serving
# 8642 (an older download) so this copy wins. Double-click it (needs python3).
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$HERE/flove-solo"
PORT=8642
ENTRY="start.html"
URL="http://localhost:${PORT}/${ENTRY}"
lan_ips() { ipconfig getifaddr en0 2>/dev/null; ipconfig getifaddr en1 2>/dev/null; }
ts_url() { command -v tailscale >/dev/null 2>&1 && tailscale ip -4 2>/dev/null | head -1 | sed "s#^#http://#; s#\$#:$PORT#"; }
write_devices() {
  local out lan="[" ip ts fst=1
  for ip in $(lan_ips); do
    [ -n "$ip" ] || continue
    if [ "$fst" -eq 1 ]; then lan="$lan\"http://$ip:$PORT\""; fst=0; else lan="$lan, \"http://$ip:$PORT\""; fi
  done
  out="{\"port\":$PORT,\"localhost\":\"$URL\",\"lan\":$lan]"
  ts="$(ts_url)"; [ -n "$ts" ] && out="$out,\"tailscale\":\"$ts\""
  printf '%s\n' "$out" > "$ROOT/devices.json" 2>/dev/null || true
}
port_open() { (exec 3<>"/dev/tcp/127.0.0.1/${PORT}") 2>/dev/null; }
stop_existing() {
  local pids=""
  if command -v lsof >/dev/null 2>&1; then
    pids="$(lsof -ti tcp:8642 2>/dev/null | tr '\n' ' ')"
  else
    pids="$(pgrep -f 'http.server 8642' 2>/dev/null | tr '\n' ' ')"
  fi
  [ -n "$pids" ] || return 0
  kill $pids 2>/dev/null || true
  sleep 0.3
  osascript -e 'display notification "Se reemplazó un flove localhost anterior; esta copia es la activa." with title "flove"' 2>/dev/null || \
    echo "flove: actualizado — se reemplazó un flove localhost anterior." >&2
}
stop_existing
write_devices
if ! port_open; then
  cd "$ROOT" || exit 1
  if command -v python3 >/dev/null; then
    nohup python3 -m http.server "$PORT" >/tmp/flove-server.log 2>&1 &
    for _ in $(seq 1 20); do port_open && break; sleep 0.2; done
  fi
fi
if port_open; then open "$URL"; else open "$ROOT/start.html"; fi
