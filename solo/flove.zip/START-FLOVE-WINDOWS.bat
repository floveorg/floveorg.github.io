@echo off
REM START-FLOVE.bat - serves the flove\ folder and opens START.html on localhost:8642
setlocal
cd /d "%~dp0flove"
where python >nul 2>nul
if %errorlevel%==0 (
  start "flove server" /min python -m http.server 8642
  timeout /t 1 >nul
  start "" http://localhost:8642/START.html
  goto :eof
)
where py >nul 2>nul
if %errorlevel%==0 (
  start "flove server" /min py -m http.server 8642
  timeout /t 1 >nul
  start "" http://localhost:8642/START.html
  goto :eof
)
echo Python not found - opening the file directly ^(some features may be limited^).
start "" START.html
