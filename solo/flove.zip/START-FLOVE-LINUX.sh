#!/usr/bin/env bash
# START-FLOVE-LINUX.sh — run this. Serves the flove/ folder beside this script and
# opens flove/START.html at http://localhost:8642. On first run it also drops a flove
# icon into your applications menu (and Desktop), so next time you launch from there.
set -uo pipefail

SELF="$(readlink -f "$0")"
HERE="$(cd "$(dirname "$SELF")" && pwd)"
ROOT="$HERE/flove"                      # web root = the flove/ folder next to this script
PORT=8642
ENTRY="START.html"
URL="http://localhost:${PORT}/${ENTRY}"

port_open() { (exec 3<>"/dev/tcp/127.0.0.1/${PORT}") 2>/dev/null; }
opener() { xdg-open "$1" >/dev/null 2>&1 || open "$1" >/dev/null 2>&1 & }

# Create a real menu/desktop icon that points back to this very script.
make_icon() {
  local apps="$HOME/.local/share/applications"
  mkdir -p "$apps" 2>/dev/null || return 0
  cat > "$apps/flove-localhost.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=flove (localhost)
Comment=Serve flove on localhost and open it
Exec="$SELF"
Icon=$ROOT/images/flove-icon.svg
Terminal=false
StartupNotify=true
Categories=Network;
EOF
  chmod +x "$apps/flove-localhost.desktop" 2>/dev/null || true
  update-desktop-database "$apps" >/dev/null 2>&1 || true
  if [ -d "$HOME/Desktop" ]; then
    cp "$apps/flove-localhost.desktop" "$HOME/Desktop/" 2>/dev/null || true
    chmod +x "$HOME/Desktop/flove-localhost.desktop" 2>/dev/null || true
    gio set "$HOME/Desktop/flove-localhost.desktop" metadata::trusted true 2>/dev/null || true
  fi
}
make_icon

if ! port_open; then
  cd "$ROOT" || { command -v notify-send >/dev/null && notify-send "flove" "No encuentro la carpeta flove/"; exit 1; }
  nohup python3 -m http.server "$PORT" >/tmp/flove-server.log 2>&1 &
  disown
  for _ in $(seq 1 20); do port_open && break; sleep 0.2; done
fi

if port_open; then
  opener "$URL"                          # localhost: reliable storage + secure context
else
  command -v notify-send >/dev/null && notify-send "flove" \
    "Sin servidor local — abriendo el fichero directo (file://), modo degradado."
  opener "$ROOT/${ENTRY}"
fi
