# Pending Questions

> **Next milestone: JSON distro** (routing.json + metadata + trusty cleanup + app links).
> Backend decisions documented in `central-backend.md`. New questions below.

---

## Remaining Pending Items

### Banco Risa

#### BR03 — How should `/setprivacy` be verified in BotFather?

**Decision:** Unanswered — defer to Marc.

#### BR04 — How should the banco moderation design be finalized?

**Decision:** Wait for Marc review (option a) — Pendiente revisión Marc.

---

### Nety

#### N01 — How should nety master be reconciled with GitHub divergence?

**Decision:** Unanswered — defer to Marc.

#### NF02 — What happens to mask data when the user clears browser storage?

**Decision:** Discussion in progress.

---

## Resolved Questions (archived)

All resolved questions documented in:
- `plans/browser-extension.md` (BX01-BX10, BF01-BF14, BL01-BL11, BA01-BA03, BD01-BD29)
- `plans/central-backend.md` (CB01-CB40, CB_S01-CB_S10, CA01-CA03)
- `plans/nety-frontend.md` (NF01-NF10, NP01-NP02)
- `plans/nety-trust.md` (NT01-NT10, TV01-TV02)
- `plans/conflicts.md` (conflict resolutions)
- `standards/persistence.md` (CC01)
