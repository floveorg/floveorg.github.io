# Pendings

Punteros desde los docs: `↗ pendings:#N` (donde N es el ID).

**Interview de decisiones:** en `making-of.html` → entrada "Various — Design Decisions". Ver también `pending-questions.md` para las preguntas resueltas.

**Implementation plans & conflicts:** [`plans/index.md`](plans/index.md) · [`plans/conflicts.md`](plans/conflicts.md)

---

## Pending Items

### Banco Risa
- **BR03** Verificar `/setprivacy` → Disable en BotFather → unanswered (defer to Marc)
- **BR04** ~~Design `risa-banco-telegram-moderation-design.md` — pendiente revisión Marc~~ → ✅ Wait for Marc review
- **BR05** Banco Phase 1: swap `banco.json` a cross-origin Pages URL, vaciar placeholder seed, añadir QR code en modal

### Git History
- **GH01** Force push a GitHub si es necesario (reescritura de historia)

### Coming Soon (deferred)
- **CS01** Save app button in menús → repo download link (no implementar)

### Nety
- **N01** Reconcile nety master — diverge de GitHub (26+5 commits) → unanswered (defer to Marc)
- **N03** ~~Nety tagline en `flove-tiers-matrix.html`: "coming soon" → definir~~ → ✅ Coming soon (keep placeholder)
- **NF02** Mask data clearing — discussion in progress (needs deeper conversation)

### Architecture
- **ARCH01** MyNet trust computation: Python Central (FastAPI) for now, migrate to Rust Nety later
- **ARCH02** Browser Extension + Central = CORE; Decentral Nety = P2P distributed computation only
- **ARCH03** Repo structure: `central/` + `decentral/` (nety is sub-folder)
- **ARCH04** First 6 Central apps: rewrite from scratch (TBD)
- **ARCH05** Decentral Nety repo: create `decentral/` with nety as sub-folder

### Validación & Pulido
- **V03** Workflow de mantenimiento por tiers

### Worldview
- **W01** Dump Whole → worldview §3

### Tiers & Builds
- **T02** Super tier placeholder in-development
- **T03** Mega tier reserved, not featured yet
- **T04** Nano/mega not yet authored
- **T06** ~~Sound-depth control pending a new design~~ → ✅ Volume slider
- **T07** ~~Narrativa/Films axis → standard del tier Super~~ → ✅ Interactive storytelling

### Backend & Export
- **BE02** ~~Publish.md: "more" publish mode placeholder para nety·0asis~~ → ✅ API integration
- **BE03** ~~Coordinates.md: flove-quality measure, Tiers >5, Gitea↔docs sibling rule~~ → ✅ Defer until core features complete
- **CB_S10** Rating widget + puzzy integration — defer to design puzzy more appropriately first

### Designs Pendientes
- **DS01** ~~`flove-pwa-installable-design.md` — pendiente plan de implementación~~ → ✅ Simple install prompt
- **DS02** ~~`flove-private-addon-login-encryption-design.md` — pendiente plan de implementación~~ → ✅ OAuth integration
- **DS03** `appy-advanced-athenea-desk.md` — Tasks 6 (wizy.html), 7 (sety.html), 8 (making-of.html)
- **DS04** `appy-intros-rainbow-roadmap-design.md` — features-intro stubbed, nav location TBD

### Android / APK
- **APK01** Android SDK no instalado — necesario para `bubblewrap build`

### Otros
- **O01** Actualizar MEMORY.md con cambios recientes
- **O02** Propagate Ken Burns minivideo animation to all apps caption sliders (goddy done as template)
- **O03** Browser extension decisions pending:
  - BE07: Context menu behavior (1. open in flove, 2. save selection, 3. both)
  - BE09: flove-bridge.js integration (1. opt-in attribute, 2. auto-detect URL, 3. both)

---

## Resolved (archived)

All decisions documented in `pending-questions.md` and `central-backend.md`.
