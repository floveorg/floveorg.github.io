# ✺ flove · Strategic Persistence Plan

> Ephemerall standard meets real-world persistence needs.
> Flove as case study for persistence parameters.

## Ephemerall Standard (SD09)

**Core rule:** Survive close, reload resets.

But "reload resets" needs nuance — some data MUST persist (identity, settings), some SHOULD be ephemeral (session state), some CAN go either way (app data).

## Persistence Tiers

| Tier | Survives | Resets on | Example |
|------|----------|-----------|---------|
| **P0: Permanent** | Everything | Manual delete only | Identity, settings, trust scores |
| **P1: Session** | Tab close | Browser restart | Current mask, active tab |
| **P2: Ephemeral** | Nothing | Reload | Selections, drafts, UI state |

## Flove Case Study: App Persistence Matrix

| App | P0 (Permanent) | P1 (Session) | P2 (Ephemeral) |
|-----|----------------|--------------|----------------|
| **blogy** | Read list, ratings | Current article | Scroll position |
| **souls** | Soul profile, connections | Active soul | Selection state |
| **goddy** | Published items, drafts | Current draft | Form inputs |
| **inventary** | Inventory items | Current item | Filter state |
| **myfamily** | Family tree, members | Active member | View mode |
| **keys** | Key pairs, vault | Current key | Search query |
| **browsy** | Trust scores, web of trust (3 hops, 100 users LRU) | Active mask | Panel state |
| **nety** | Profile, circles, trust | Active circle | Feed position |

## Storage Mechanisms

| Mechanism | Limit | Use for | Flove apps |
|-----------|-------|---------|------------|
| **localStorage** | 5-10MB | P0 settings, simple data | All apps |
| **sessionStorage** | 5-10MB | P1 session state | blogy, browsy |
| **IndexedDB** | 50-200MB | P0 complex data, P1 large state | browsy (trust), nety (circles) |
| **Cache API** | Varies | Offline app copies | browsy (fallback) |
| **Extension storage** | 100MB | browsy core data | browsy only |

## Persistence Parameters

### Size Budgets

| Data Type | Max Size | Eviction | Storage |
|-----------|----------|----------|---------|
| **User profile** | 10KB | Never | localStorage |
| **Trust scores** | 100KB | LRU | IndexedDB |
| **Web of trust** | 1MB | LRU (3 hops, 100 users) | IndexedDB |
| **App data** | 10MB | App-defined | localStorage/IndexedDB |
| **Offline apps** | 50MB | LRU | Cache API |
| **Extension core** | 100MB | User-managed | Extension storage |

### Eviction Policies

| Policy | When to use | Flove apps |
|--------|-------------|------------|
| **LRU** | Trust data, app data | browsy, nety |
| **Time-based** | Session state | All apps |
| **Size-based** | Offline cache | browsy |
| **Never** | Identity, settings | All apps |
| **User-managed** | Large data | browsy (100MB) |

### Compression

| Type | Method | Reduction | Use for |
|------|--------|-----------|---------|
| **JSON** | gzip | ~70% | Trust data, profiles |
| **Delta** | Only changes | Significant | Frequent updates |
| **Binary** | Array buffers | ~50% | Media, large blobs |

## Central Persistence

| Layer | Storage | Persistence | Notes |
|-------|---------|-------------|-------|
| **User data** | Turso (libSQL) | Permanent | `app_data` table |
| **User config** | Turso (libSQL) | Permanent | `user_config` table |
| **Pending sync** | localStorage | Session | `flove:pending-sync` flag |
| **Cache** | localStorage | Session | `central=available` flag |

## Browsy Persistence

| Layer | Storage | Persistence | Notes |
|-------|---------|-------------|-------|
| **Trust scores** | IndexedDB | Permanent | LRU, 100 users max |
| **Web of trust** | IndexedDB | Permanent | 3 hops, LRU |
| **Profiles** | IndexedDB | Permanent | JSON-LD generated locally |
| **Webhook configs** | Extension storage | Permanent | User-configurable |
| **Export history** | localStorage | Session | Last 10 exports |
| **Panel state** | sessionStorage | Tab close | Current view |

## Implementation Rules

### Rule 1: P0 data must have export/import
Every P0 data type must support export (JSON download) and import (file upload or webhook).

### Rule 2: P1 data must have defaults
Every P1 data must have sensible defaults if missing (no "undefined" states).

### Rule 3: P2 data must be optional
P2 data is nice-to-have, never required for core functionality.

### Rule 4: Size limits must be enforced
Check before writing. Show warning at 80%. Evict at 100%.

### Rule 5: Compression for large data
Any data >10KB should be compressed before storage.

## Migration Strategy

When persistence format changes (CC05: version-check on load):

1. Check `flove:version` in localStorage
2. If version mismatch, run migration script
3. Migration scripts are pure functions: `(oldData) => newData`
4. Store new version after successful migration
5. Never delete old data until migration confirmed

## Flove-Specific Patterns

### The `flove:` namespace
All flove localStorage keys use `flove:` prefix:
- `flove:lang` — language setting (app-agnostic)
- `flove:theme` — theme setting (app-agnostic)
- `flove:pending-sync` — Central sync flag
- `flove:<app>:*` — app-specific data
- `flove:version` — schema version

### The `collect()` contract
Apps define `window.flove.collect()` to specify what data to sync to Central. This is the boundary between P0 (synced) and P2 (local only).

### The ephemerall reset
On "reload resets", apps should:
1. Clear P2 data
2. Reset P1 data to defaults
3. Preserve P0 data
4. Show onboarding if first visit
