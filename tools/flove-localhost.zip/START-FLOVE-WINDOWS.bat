@echo off
REM START-FLOVE-WINDOWS.bat - serves the flove-localhost folder and opens index.html on localhost:8642
REM Update behavior: stops anything already serving 8642 (a previous download) so this copy wins.
setlocal
if not exist "%~dp0flove-localhost\index.html" (
  echo The archive was not fully extracted: the flove-localhost folder is missing.
  echo Extract the WHOLE .zip ^(flove-localhost\ must sit next to this .bat^), then run it again.
  pause
  exit /b 1
)
cd /d "%~dp0flove-localhost"
for /f "tokens=5" %%a in ('netstat -ano ^| findstr /r ":8642 .*LISTENING"') do (
  taskkill /F /PID %%a >nul 2>nul
  set "REPLACED=1"
)
if defined REPLACED echo Updated: replaced an older flove localhost; this copy is now active.
echo For a phone: open http://<this-PC-LAN-IP>:8642/ from the same Wi-Fi. Scan the QR in the app (Settings > Devices).
where python >nul 2>nul
if %errorlevel%==0 (
  start "flove server" /min python -m http.server 8642
  timeout /t 1 >nul
  start "" http://localhost:8642/index.html
  goto :eof
)
where py >nul 2>nul
if %errorlevel%==0 (
  start "flove server" /min py -m http.server 8642
  timeout /t 1 >nul
  start "" http://localhost:8642/index.html
  goto :eof
)
echo Python not found - opening the file directly ^(some features may be limited^).
start "" index.html
